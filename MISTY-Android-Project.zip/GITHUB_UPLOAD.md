# Upload this project to GitHub

This ZIP is the complete Android project. Do not upload only this ZIP file and expect GitHub Actions to build it.

1. Extract this ZIP on your computer or phone.
2. Open your GitHub repository.
3. Upload the CONTENTS of the extracted folder to the repository root (the same level as `.github`, `app`, `gradlew`, and `settings.gradle.kts`).
4. If GitHub asks whether to replace `.github/workflows/android-build.yml`, replace the old workflow with this one.
5. Commit the uploaded files. The workflow runs on push to `main` or `master`, or manually from Actions → MISTY Android Build → Run workflow.
6. When successful, download the `MISTY-Android-APK` artifact from the workflow run.

Expected repository root:

```text
.github/workflows/android-build.yml
app/
gradle/
gradlew
gradlew.bat
build.gradle.kts
settings.gradle.kts
gradle.properties
```

The workflow checks these files before building. If `gradlew` is still not found, the project contents were not uploaded to the repository root.

This is a debug APK workflow. It does not create a Play Store release-signed APK.
