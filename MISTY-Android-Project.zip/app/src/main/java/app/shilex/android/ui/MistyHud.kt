package app.shilex.android.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * What MISTY is doing right now. [spin] is how many turns the rings make per cycle (0 = standing
 * still, which costs no battery).
 */
enum class MistyState(val tint: Color, val energy: Float, val spin: Int) {
    Idle(Color(0xFF2FD6FF), 0f, 0),
    Listening(Color(0xFF2FD6FF), 0.55f, 1),
    Processing(Color(0xFF8AB4FF), 0.7f, 3),
    Executing(Color(0xFF3DF2C0), 0.7f, 2),
    Speaking(Color(0xFFB69CFF), 0.9f, 1),
    Error(Color(0xFFFF6B6B), 0.3f, 0),
}

/**
 * The HUD core: turning rings, tick marks and a glowing centre that swells with the voice [level]
 * (0..1). Idle and error are single still frames.
 */
@Composable
fun MistyHud(state: MistyState, level: Float, modifier: Modifier = Modifier) {
    val tint by animateColorAsState(state.tint, tween(600), label = "tint")
    val energy by animateFloatAsState(state.energy, tween(600), label = "energy")
    val voice by animateFloatAsState(level.coerceIn(0f, 1f), spring(stiffness = Spring.StiffnessLow), label = "voice")
    val animated = state != MistyState.Idle && state != MistyState.Error
    val t = if (animated) {
        rememberInfiniteTransition(label = "hud").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(HUD_CYCLE_MS, easing = LinearEasing), RepeatMode.Restart),
            label = "t",
        ).value
    } else {
        0f
    }
    val working = state == MistyState.Processing || state == MistyState.Executing

    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f
        val px = density
        val spin = t * 360f * state.spin

        // Faint radar cross.
        val faint = tint.copy(alpha = 0.10f)
        drawLine(faint, Offset(c.x - r, c.y), Offset(c.x + r, c.y), strokeWidth = px)
        drawLine(faint, Offset(c.x, c.y - r), Offset(c.x, c.y + r), strokeWidth = px)

        // Glow behind everything, brighter with the voice.
        drawCircle(
            Brush.radialGradient(listOf(tint.copy(alpha = 0.18f + 0.30f * voice + 0.12f * energy), Color.Transparent), c, r),
            radius = r,
            center = c,
        )

        // Outer ring with tick marks.
        drawCircle(tint.copy(alpha = 0.55f), radius = r * 0.97f, center = c, style = Stroke(width = 1.5f * px))
        rotate(spin * 0.25f) {
            for (i in 0 until 72) {
                val a = i * 2f * PI.toFloat() / 72f
                val long = i % 6 == 0
                val from = r * (if (long) 0.88f else 0.92f)
                val to = r * 0.95f
                drawLine(
                    tint.copy(alpha = if (long) 0.8f else 0.35f),
                    Offset(c.x + from * cos(a), c.y + from * sin(a)),
                    Offset(c.x + to * cos(a), c.y + to * sin(a)),
                    strokeWidth = (if (long) 2f else 1f) * px,
                )
            }
        }

        // Dashed ring turning the other way.
        val dash = PathEffect.dashPathEffect(floatArrayOf(14f * px, 10f * px))
        rotate(-spin * 0.5f) {
            drawCircle(tint.copy(alpha = 0.45f), radius = r * 0.78f, center = c, style = Stroke(width = 2f * px, pathEffect = dash))
        }

        // Three bright arcs.
        rotate(spin) {
            val ar = r * 0.66f
            for (k in 0 until 3) {
                drawArc(
                    tint.copy(alpha = 0.85f),
                    startAngle = k * 120f + 8f,
                    sweepAngle = 70f,
                    useCenter = false,
                    topLeft = Offset(c.x - ar, c.y - ar),
                    size = Size(ar * 2f, ar * 2f),
                    style = Stroke(width = 4f * px, cap = StrokeCap.Round),
                )
            }
        }

        // Thinking or doing: a comet chasing round the middle.
        if (working) {
            val cr = r * 0.54f
            rotate(spin * 2f) {
                drawArc(
                    Brush.sweepGradient(listOf(Color.Transparent, tint, Color.Transparent), c),
                    startAngle = 0f,
                    sweepAngle = 140f,
                    useCenter = false,
                    topLeft = Offset(c.x - cr, c.y - cr),
                    size = Size(cr * 2f, cr * 2f),
                    style = Stroke(width = 3f * px),
                )
            }
        }

        // The core.
        val core = r * (0.34f + 0.06f * voice + 0.02f * energy)
        drawCircle(
            Brush.radialGradient(listOf(Color.White.copy(alpha = 0.9f), tint, tint.copy(alpha = 0.15f)), c, core * 1.3f),
            radius = core,
            center = c,
        )
        drawCircle(tint.copy(alpha = 0.7f), radius = core * 1.12f, center = c, style = Stroke(width = 2f * px))
    }
}

/** A row of bars under the core: moves with the voice while listening or speaking, a flat line otherwise. */
@Composable
fun MistyWave(state: MistyState, level: Float, modifier: Modifier = Modifier) {
    val tint by animateColorAsState(state.tint, tween(600), label = "waveTint")
    val live = state == MistyState.Listening || state == MistyState.Speaking
    val voice by animateFloatAsState(level.coerceIn(0f, 1f), spring(stiffness = Spring.StiffnessMedium), label = "waveLevel")
    val t = if (live) {
        rememberInfiniteTransition(label = "wave").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(WAVE_CYCLE_MS, easing = LinearEasing), RepeatMode.Restart),
            label = "wt",
        ).value
    } else {
        0f
    }

    Canvas(modifier) {
        val n = 33
        val gap = size.width / n
        val mid = size.height / 2f
        val phase = t * 2f * PI.toFloat()
        for (i in 0 until n) {
            val x = gap * (i + 0.5f)
            val shape = 0.35f + 0.65f * abs(sin(i * 0.55f + phase))
            val edge = 1f - abs(i - n / 2f) / (n / 2f) * 0.7f
            val amp = if (live) (0.12f + 0.88f * voice.coerceAtLeast(0.15f)) * shape * edge else 0.06f
            val h = size.height * 0.5f * amp
            drawLine(
                tint.copy(alpha = if (live) 0.9f else 0.35f),
                Offset(x, mid - h),
                Offset(x, mid + h),
                strokeWidth = gap * 0.45f,
                cap = StrokeCap.Round,
            )
        }
    }
}

private const val HUD_CYCLE_MS = 12_000
private const val WAVE_CYCLE_MS = 1_600
