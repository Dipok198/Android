package app.shilex.android.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.shilex.android.R

/**
 * Lightweight portrait treatment using the user's supplied avatar reference.
 * Motion is intentionally subtle and state-driven to avoid a continuously expensive renderer.
 * This is not phoneme-level lip-sync; that needs a dedicated animated character rig and audio
 * viseme/timing data, neither of which is present in the supplied project.
 */
@Composable
fun MistyAvatar(
    speaking: Boolean,
    listening: Boolean,
    modifier: Modifier = Modifier,
    diameter: Dp = 88.dp,
) {
    val transition = rememberInfiniteTransition(label = "mistyAvatarIdle")
    val drift by transition.animateFloat(
        initialValue = -2.5f,
        targetValue = 2.5f,
        animationSpec = infiniteRepeatable(tween(3_200), RepeatMode.Reverse),
        label = "avatarDrift",
    )
    val scale by animateFloatAsState(
        targetValue = if (speaking) 1.035f else if (listening) 1.015f else 1f,
        animationSpec = tween(420),
        label = "avatarStateScale",
    )
    val ring = if (speaking) Color(0xFFB69CFF) else if (listening) Color(0xFF2FD6FF) else Color(0xFF287DAD)

    Box(
        modifier = modifier
            .size(diameter)
            .graphicsLayer {
                translationY = drift
                scaleX = scale
                scaleY = scale
            }
            .shadow(18.dp, CircleShape, ambientColor = ring.copy(alpha = 0.35f), spotColor = ring.copy(alpha = 0.55f))
            .background(Brush.radialGradient(listOf(ring.copy(alpha = 0.35f), Color(0xFF071525))), CircleShape)
            .border(1.5.dp, ring.copy(alpha = 0.9f), CircleShape)
            .clip(CircleShape)
            .semantics { contentDescription = "MISTY female avatar" },
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(R.drawable.misty_avatar),
            contentDescription = "MISTY avatar based on the supplied reference photograph",
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(diameter - 7.dp).clip(CircleShape),
        )
    }
}


/** Large portrait treatment used by the main MISTY dashboard. */
@Composable
fun MistyPortrait(speaking: Boolean, listening: Boolean, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "mistyPortrait")
    val drift by transition.animateFloat(-2f, 2f, infiniteRepeatable(tween(3600), RepeatMode.Reverse), label = "portraitDrift")
    val scale by animateFloatAsState(if (speaking) 1.012f else 1f, tween(500), label = "portraitScale")
    val glow = when { speaking -> Color(0xFFB69CFF); listening -> Color(0xFF2FD6FF); else -> Color(0xFF168FC8) }
    Box(
        modifier = modifier
            .graphicsLayer { translationY = drift; scaleX = scale; scaleY = scale }
            .shadow(24.dp, androidx.compose.foundation.shape.RoundedCornerShape(28.dp), ambientColor = glow.copy(alpha = .35f), spotColor = glow.copy(alpha = .45f))
            .background(Brush.verticalGradient(listOf(Color(0xFF0B2942), Color(0xFF06111F))), androidx.compose.foundation.shape.RoundedCornerShape(28.dp))
            .border(1.5.dp, glow.copy(alpha = .85f), androidx.compose.foundation.shape.RoundedCornerShape(28.dp))
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(28.dp)),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(R.drawable.misty_avatar),
            contentDescription = "MISTY female avatar based on your reference photograph",
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(210.dp, 264.dp),
        )
        Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(52.dp).background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEE06111F)))))
        androidx.compose.material3.Text(
            text = if (speaking) "MISTY • SPEAKING" else if (listening) "MISTY • LISTENING" else "MISTY • ONLINE",
            color = Color(0xFF9DEBFF),
            style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp),
        )
    }
}
