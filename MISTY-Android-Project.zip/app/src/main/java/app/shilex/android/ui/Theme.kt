package app.shilex.android.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Dark = darkColorScheme(
    primary = Color(0xFF2FD6FF),
    onPrimary = Color(0xFF001F29),
    primaryContainer = Color(0xFF0B3347),
    onPrimaryContainer = Color(0xFFBDF1FF),
    secondary = Color(0xFF8FB4D6),
    tertiary = Color(0xFFFFB454),
    background = Color(0xFF05080F),
    onBackground = Color(0xFFE6F4FF),
    surface = Color(0xFF05080F),
    onSurface = Color(0xFFE6F4FF),
    // Glass panels: translucent navy with a thin cyan edge, over the animated backdrop.
    surfaceVariant = Color(0x990B1A2C),
    onSurfaceVariant = Color(0xFF8FA9C4),
    surfaceContainer = Color(0xE60A1424),
    surfaceContainerLow = Color(0xE60A1424),
    surfaceContainerHigh = Color(0xFF0E1B2C),
    surfaceContainerHighest = Color(0xFF12233A),
    outline = Color(0xFF1E4560),
    outlineVariant = Color(0x552FD6FF),
    error = Color(0xFFFF6B6B),
)

private val Light = lightColorScheme(
    primary = Color(0xFF00708A),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD4F3FA),
    onPrimaryContainer = Color(0xFF00313D),
    secondary = Color(0xFF52627A),
    tertiary = Color(0xFFA35F00),
    background = Color(0xFFF5F7FA),
    onBackground = Color(0xFF111722),
    surface = Color(0xFFF5F7FA),
    onSurface = Color(0xFF111722),
    surfaceVariant = Color(0xFFFFFFFF),
    onSurfaceVariant = Color(0xFF5B677A),
    surfaceContainer = Color(0xFFFFFFFF),
    outline = Color(0xFFD5DCE6),
    outlineVariant = Color(0xFFE4E9F0),
    error = Color(0xFFB3261E),
)

private val Type = Typography(
    displaySmall = TextStyle(fontSize = 30.sp, lineHeight = 36.sp, fontWeight = FontWeight.Light, letterSpacing = 3.sp),
    headlineSmall = TextStyle(fontSize = 24.sp, lineHeight = 30.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.2).sp),
    titleLarge = TextStyle(fontSize = 20.sp, lineHeight = 26.sp, fontWeight = FontWeight.Medium, letterSpacing = 2.sp),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.Medium),
    titleSmall = TextStyle(fontSize = 13.sp, lineHeight = 18.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.6.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 23.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.3.sp),
)

private val Corners = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
)

/** MISTY is always dark: a cinematic HUD look, whatever the phone's setting. */
@Composable
fun ShilexTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = Dark,
        typography = Type,
        shapes = Corners,
        content = content,
    )
}

// Short names the screens use; they follow light and dark mode.
val Accent: Color @Composable @ReadOnlyComposable get() = MaterialTheme.colorScheme.primary
val Background: Color @Composable @ReadOnlyComposable get() = MaterialTheme.colorScheme.background
val Surface: Color @Composable @ReadOnlyComposable get() = MaterialTheme.colorScheme.surfaceVariant
val Muted: Color @Composable @ReadOnlyComposable get() = MaterialTheme.colorScheme.onSurfaceVariant
val Warning: Color @Composable @ReadOnlyComposable get() = MaterialTheme.colorScheme.tertiary
